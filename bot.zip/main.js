const mineflayer = require('mineflayer');
const { pathfinder, Movements, goals: { GoalNear } } = require('mineflayer-pathfinder')
var Vec3 = require('vec3').Vec3;
const fs = require('fs')
const Config = require('./Config.js')

global.defaultMove = null;

class CBot{
        constructor(conf){
                conf = conf || {};
                this.config = new Config('bot.json');
                let session
                try {
                    session = JSON.parse(fs.readFileSync('session.json', 'utf8'))
                } catch (err) {
                }
                this.state = '';
                console.log('new bot...');
                this.bot = mineflayer.createBot({
                        host: conf.ip || 'mcfallout.net', // minecraft server ip
                        username: conf.user || 'mcbot800@outlook.com', // minecraft username
                        password: conf.pass || 'bairi999', // minecraft password, comment out if you want to log into online-mode=false servers
                        port: conf.port || 25565,                // only set if you need a port that isn't 25565
                        version: '1.19.3',             // only set if you need a specific version or snapshot (ie: "1.8.9" or "1.16.5"), otherwise it's set automatically
                        auth: 'microsoft',              // only set if you need microsoft auth, then set this to 'microsoft'
                        session
                });
                this.needBack = 0;
                this.work_res = "";
                this.bot.loadPlugin(pathfinder);
                this.digBotParam = {startPos:{}, endPos:{}, prePos:{}, nowPos:{}};
                this.manager = [];
                this.init();
                setTimeout(()=>{
                    console.log('開始執行......');
                    this.run();
                }, 3000);
        }

        async run(){
            for(;;){
                    switch(this.state){
                        case 'digging':
                            if(!this.needBack){
                                await this.goNextPosAndDig();
                            }
                        break;
                        case 'follow':
                        break;
                        case 'place':
                        break;
                        default:
                            await this.sleep(1000);
                        break;
                    }
            }
        }
        init(){
                console.log('init...');
                this.digBotParam.endPos = this.config.get('dig_end');
                this.digBotParam.startPos = this.config.get('dig_start');
                this.digBotParam.nowPos = this.config.get('dig_now');
                this.manager = this.config.get('manager') || ['xiaomingbai'];
                this.work_res = this.config.get('work_res');


                this.bot._client.on('session', () => {
                     console.log(this.bot._client.session)
                     fs.writeFileSync('session.json', JSON.stringify(this.bot._client.session))
                });
                this.bot.on('error', (err)=>{
                        console.log('error:', err);
                });
                this.bot.on('login', ()=>{
                        console.log('login');
                });
                this.bot.on('death', () => {
                        this.needBack = 1;
                        console.log('I died. Respawning...');
                });
                this.bot.on('connect', () => {
                        console.log('Logged in as user: [' + this.bot._client.username + ']');
                });
                this.bot.on('end', (err)=>{
                        console.log('end......');
                        process.exit(0);
                });

                this.bot.on('spawn', async () =>{
                        if(this.needBack){
                            this.needBack = 0;
                            console.log('復活，自動返回');
                            await this.sleep(1000);
                            this.bot.chat('/back');
                        }
                });
                this.bot.once('spawn', async () =>{
                        console.log('spawn...');
                        this.bot.entity.speed = 0.5;
                        if(this.work_res){
                            this.bot.chat('/warp ' + this.work_res);
                        }
                        defaultMove = new Movements(this.bot);
                        this.bot.on('message', (jsonMsg, position, sender, verified)=>{
                                console.log('message-position:', JSON.stringify(position));
                //                console.log('message:', JSON.stringify(jsonMsg));
                                console.log('message parse:', this.procMsg(this.getStr(jsonMsg)));
                                this.onMsg(this.procMsg(this.getStr(jsonMsg)));
                        });
                        this.bot.on('chat', (username, message)=>{
                        });
                        await this.sleep(3000);
                        this.state = this.config.get('state');
                });
        }

        onMsg(msg){
            console.log('onMsg:', msg);
            if(msg.type == 'whisper'){
                if(this.manager.indexOf(msg.from) < 0){
                    console.log('on other whister:', JSON.stringify(msg));
                    return;
                }
                if(msg.text.substr(0, 1) != '!'){
                    this.bot.chat(msg.text);
                }
                console.log('收到請求準備執行:', msg.text);
                this.runMsgCmd(msg.text, msg.from);
            }
        }

        async goFollow(){
                let pos = {};
                let res = await this.goToPosition(pos.x, pos.y, pos.z, 30000);
                console.log('尋路：', res);
                if(res != 0){
                    console.log('找不到玩家, 準備tpa');
                }
        }

        async goNextPosAndDig(){
                console.log('digParam:', this.digBotParam);
                let pos = this.getDigNextPos(this.digBotParam.nowPos, this.digBotParam.startPos, this.digBotParam.endPos);
                console.log('得到下一個位置：', pos);
                console.log('正在前往：', JSON.stringify(pos));
                //await this.goto(pos.x, pos.y, pos.z, 0);
                await this.sleep(20);
                let res = await this.goToPosition(pos.x, pos.y, pos.z, 30000);
                console.log('尋路：', res);
                for(let i = 0; i < 5; i++){
                    await this.sleep(20);
                    await this.doDig(pos.x, pos.y + i, pos.z);
                }
                this.digBotParam.nowPos = {x:pos.x, y:pos.y, z:pos.z};
                this.config.set('dig_now', this.digBotParam.nowPos);
                if(pos.x == this.digBot.Param.endPos.x && pos.z == this.digBot.param.endPos.z){
                        this.config.set('state', 'cancel');
                        this.bot.chat('挖掘任務已經完成，當前狀態:' + this.state);
                }
        }
        async runMsgCmd(message, from){
                let params = message.split(' ');
            console.log('['+message + ']', params);
            if(params[0] == '!go'){
                    //this.goto(params[1] * 1, params[2] * 1, params[3] * 1);
                    let res = await this.goToPosition(params[1] * 1, params[2] * 1, params[3] * 1, 30000);
                    console.log(res);
            }
            if(params[0] == '!tpme'){
                 this.bot.chat('/tpa ' + from);
            }
            if(params[0] == '!set_dig_start'){
                this.digBotParam.startPos = {x:params[1] * 1, y:params[2] * 1, z:params[3] * 1};
                this.digBotParam.nowPos = {x:params[1] * 1, y:params[2] * 1, z:params[3] * 1};
                this.config.set('dig_start', this.digBotParam.startPos);
                this.config.set('dig_now', this.digBotParam.startPos);
                this.bot.chat('/m ' + from + ' 設置成功');
            }
            if(params[0] == '!set_dig_end'){
                this.digBotParam.endPos = {x:params[1] * 1, y:params[2] * 1, z:params[3] * 1};
                this.config.set('dig_end', this.digBotParam.endPos);
                this.bot.chat('/m ' + from + ' 設置成功');
            }
            if(params[0] == '!set_work_res'){
                this.work_res = {x:params[1] * 1, y:params[2] * 1, z:params[3] * 1};
                this.config.set('work_res', this.work_res);
                this.bot.chat('/m ' + from + ' 設置成功');
            }
            if(params[0] == '!add_manager'){
                this.manager.push(params[1].trim());
                this.config.set('manager', this.manager);
                this.bot.chat('/m ' + from + ' 設置成功');
            }
            if(params[0] == '!state'){
                this.bot.chat('/m ' + from + ' ' + this.state);
            }
            if(params[0] == '!cancel'){
                this.state = 'waitting';
                this.bot.chat('/m ' + from + ' 取消當前任務，當前狀態:' + this.state);
                this.config.set('state', 'cancel');
            }
            if(params[0] == '!dig'){
                this.state= 'digging';
                this.bot.chat('/m ' + from + ' 開始挖掘任務，當前狀態:' + this.state);
                this.config.set('state', 'digging');
            }
        }
        goToPosition(x, y, z, timeout = 30000) {
                return new Promise((resolve, reject) => {
                                const targetPos = new Vec3(x, y, z);
                                const goal = new GoalNear(targetPos.x, targetPos.y, targetPos.z, 3);
                                this.bot.pathfinder.setMovements(defaultMove);
                                this.bot.pathfinder.setGoal(goal);

                                let timeoutId = setTimeout(() => {
                                                this.bot.pathfinder.setGoal(null);
                                                reject(-9);
                                                }, timeout);

                                this.bot.on('goal_reached', () => {
                                                clearTimeout(timeoutId);
                                                resolve(0);
                                                });

                                this.bot.on('path_update_failed', (err) => {
                                                clearTimeout(timeoutId);
                                                reject(-1);
                                                });

                                this.bot.on('goal_updated', (newGoal) => {
                                        if (!newGoal || newGoal.x !== targetPos.x || newGoal.y !== targetPos.y || newGoal.z !== targetPos.z) {
                                            clearTimeout(timeoutId);
                                            reject(-2);
                                        }
                                });
                });
        }

        async doDig(x, y, z){
                console.log('準備挖掘:', x, y, z);
                let target = this.bot.blockAt(new Vec3(x, y, z));
                if (!target || !this.bot.canDigBlock(target)) {
                        console.log('cannot dig');
                        return;
                }
                console.log(`starting to dig ${target.name}`);
                try {
                        let diamondPickaxe = this.bot.inventory.items().find(item => item.name === 'diamond_pickaxe');
                        if (diamondPickaxe) {
                                this.bot.equip(diamondPickaxe, 'hand');
                        }
                        await this.bot.dig(target);
                        console.log(`finished digging ${target.name}`)
                } catch (err) {
                        console.log(err.stack);
                }
        }

        sleep(ms) {
                return new Promise(resolve => setTimeout(resolve, ms));
        }
        async goto(x, y, z, s){
                this.bot.chat(`Going to ${x} ${y} ${z}`);
                this.bot.pathfinder.setMovements(defaultMove);
                this.bot.pathfinder.setGoal(new GoalNear(x, y, z, s||1));
                console.log('結束');
        }
        getStr(msg){
            let str = '';
            if( typeof(msg.extra)== 'undefined'){
                return msg.text || '';
            }
            for(let i = 0; i < msg.extra.length; i++){
                str += this.getStr(msg.extra[i]);
            }
            return str;
        }

    async getToolsFromChest(toolTypes, chestPos){
            await bot.waitForChunksToLoad();
            const chestBlock = await bot.world.getBlockAt(chestPos);
            if (!chestBlock || chestBlock.name !== 'chest') {
                    console.log('指定坐標不是有效的箱子');
                    return;
            }
            // 取得箱子方塊的實體
            const chest = await bot.openChest(chestBlock);
            // 從箱子中取出指定類型的工具
            const tools = {};
            for (const toolType of toolTypes) {
                    const toolItem = chest.items().find(item => item.name === toolType);
                    if (toolItem) {
                            // 如果箱子中有指定類型的工具，就拿出一個
                            tools[toolType] = 1;
                            chest.withdraw(toolItem.type, null, 1, () => {});
                    } else {
                            console.log(`箱子中沒有 ${toolType}`);
                    }
            }
            // 關閉箱子
            chest.close();
    }


    getPos(nowPos, maxWidth, maxHeight){
            let newPos = {x:nowPos.x, z:nowPos.z};
            let iso = (nowPos.z % 2 === 0);
            if(iso){
                    if(newPos.x <= 1){
                            console.log('ou 終點');
                            newPos.x = 1;
                            newPos.z = nowPos.z + 1;
                    }else{
                            console.log('ou x-');
                            newPos.x = nowPos.x - 1;
                            newPos.z = nowPos.z;
                    }
            }else{
                    if(nowPos.x >= maxWidth){
                            console.log('ji 終點');
                            newPos.x = maxWidth;
                            newPos.z = nowPos.z + 1;
                    }else{
                            console.log('ji x+');
                            newPos.x = nowPos.x + 1;
                            newPos.z = nowPos.z;
                    }
            }
            if(newPos.z > maxHeight){
                    return nowPos;
            }
            return newPos;
    }

    getDigNextPos(nowPos, startPos, endPos){
            let maxWidth = Math.abs(endPos.x - startPos.x);
            let maxHeight = Math.abs(endPos.z - startPos.z);
            let tmpPos = {
x:Math.abs(nowPos.x - startPos.x),
  z:Math.abs(nowPos.z - startPos.z),
            };
            console.log(maxWidth, maxHeight, tmpPos);
            let res = this.getPos(tmpPos, maxWidth, maxHeight);
            console.log('res:', res);
            return {x:endPos.x > startPos.x?startPos.x + res.x:startPos.x - res.x, y:startPos.y>endPos.y?endPos.y:startPos.y, z:endPos.z>startPos.z?startPos.z+res.z:startPos.z-res.z};
    }


    procMsg(msg){
        let data = {type:'', from:'', text:''};
        if(msg.substr(0, 1) != '['){
            data.type = 'other';
            data.text = msg;
            return data;
        }
        data.type = msg.substr(1, msg.indexOf(']') - 1);
        msg = msg.substr(msg.indexOf(']') + 2);
        data.text = msg.substr(msg.indexOf(']') + 1);
        if(msg.substr(0, 1) == '<' && msg.indexOf('>') > 0){
            data.from = msg.substr(1, msg.indexOf('>') -1);
            data.from = data.from.substr(data.from.indexOf('-') + 1).replace(/[^0-9a-zA-Z_]/g, '');
            data.text = msg.substr(msg.indexOf('>') + 2);
            msg = data.text;
        }
        if(data.type.indexOf('->') > 0){
            let from = data.type;
            data.type = 'whisper';
            data.from = from.split('->')[0].trim();
            data.text = msg;
        }
        return data;
   }


};

function main(){
        try{
                let b = new CBot();
        }catch(e){
            process.exit(0);
        }
        setInterval(function(){},9999999);   
}
main();
